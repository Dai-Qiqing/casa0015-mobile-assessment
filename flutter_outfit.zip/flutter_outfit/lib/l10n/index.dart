library l10n;

export './l10n.dart';
export './messages_all.dart';
