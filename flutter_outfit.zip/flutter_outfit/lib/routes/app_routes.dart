class AppRoutes {
  static const AUTH = '/auth';
  static const MAIN = '/main';
  static const RECORD = '/record';
  static const FAVORITE = '/favorite';
  static const RECORDER = '/recorder';
}
