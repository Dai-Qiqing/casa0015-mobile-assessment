package com.example.flutter_outfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
